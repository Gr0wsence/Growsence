# Growsence - GitHub Deployment Guide

## Project Overview
This is a modern, production-ready frontend for the Growsence education platform built with React, TypeScript, Tailwind CSS, and Framer Motion.

## Files to Push to GitHub

### Core Application Files
- `client/` - Frontend React application
- `server/` - Backend Express.js server
- `shared/` - Shared types and schemas
- `package.json` - Dependencies and scripts
- `package-lock.json` - Dependency lockfile
- `vite.config.ts` - Vite configuration
- `tailwind.config.ts` - Tailwind CSS configuration
- `tsconfig.json` - TypeScript configuration
- `drizzle.config.ts` - Database configuration
- `postcss.config.js` - PostCSS configuration
- `components.json` - shadcn/ui components config

### Important Files to Include
- `README.md` (create this)
- `.gitignore` (already exists)
- `replit.md` (project documentation)

## Manual GitHub Push Steps

### 1. Clone the Repository
```bash
git clone https://github.com/Gr0wsence/Growsence.git
cd Growsence
```

### 2. Copy Files
Copy all the project files from this Replit environment to your local repository:
- Copy the entire `client/` folder
- Copy the entire `server/` folder
- Copy the entire `shared/` folder
- Copy all config files (package.json, tsconfig.json, etc.)

### 3. Create README.md
Create a README.md file with the following content:

```markdown
# Growsence - Education & Earning Platform

A modern, production-ready frontend for Growsence education platform focused on personal growth, mental well-being, and immersive learning with affiliate earning opportunities.

## Features

- 🎓 **Educational Courses**: Personal development, mental wellness, and income generation
- 💰 **Affiliate Marketing**: Proven strategies for passive income
- 🧠 **Mental Well-being**: Comprehensive mindfulness and emotional intelligence programs
- 🚀 **Modern UI/UX**: Glassmorphism, smooth animations, and responsive design
- 🌓 **Dark/Light Theme**: Seamless theme switching with persistence
- 📱 **Mobile-First**: Fully responsive design for all devices

## Tech Stack

- **Frontend**: React 18 + TypeScript
- **Styling**: Tailwind CSS + shadcn/ui
- **Animations**: Framer Motion
- **Routing**: Wouter
- **State Management**: React Query
- **Build Tool**: Vite
- **Backend**: Express.js + TypeScript
- **Database**: PostgreSQL with Drizzle ORM

## Quick Start

1. Install dependencies:
```bash
npm install
```

2. Start development server:
```bash
npm run dev
```

3. Open http://localhost:5000 in your browser

## Project Structure

```
growsence/
├── client/          # React frontend
│   ├── src/
│   │   ├── components/  # UI components
│   │   ├── pages/       # Page components
│   │   ├── hooks/       # Custom hooks
│   │   └── lib/         # Utilities
├── server/          # Express backend
├── shared/          # Shared types
└── ...config files
```

## Available Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run preview` - Preview production build

## Features Overview

### Homepage Sections
- Hero section with typing animation
- About Growsence
- Course highlights
- Feature badges (12+ courses, 750+ students, ₹15L+ earnings)
- Student testimonials carousel
- Pricing table (Basic ₹1,499 vs Pro ₹2,999)
- How it works (Learn → Earn → Grow)
- Countdown timer for offers
- FAQ section
- Professional footer

### UI/UX Features
- Glassmorphism effects
- Smooth scroll animations
- Hover effects and transitions
- Floating WhatsApp button
- Scroll-to-top functionality
- Dark/light theme toggle
- Mobile-responsive design

## Deployment

### Vercel (Recommended)
1. Push to GitHub
2. Connect repository to Vercel
3. Deploy automatically

### Manual Deployment
1. Build the project: `npm run build`
2. Deploy the `dist/` folder to your hosting service

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make changes
4. Submit a pull request

## License

MIT License - see LICENSE file for details
```

### 4. Git Commands to Push
```bash
# Add all files
git add .

# Commit with message
git commit -m "Initial commit: Growsence education platform frontend"

# Add remote origin (if not already added)
git remote add origin https://github.com/Gr0wsence/Growsence.git

# Push to main branch
git push -u origin main
```

## Environment Variables for Production

Create a `.env.example` file:
```
DATABASE_URL=your_database_url
NODE_ENV=production
PORT=5000
```

## Key Features Implemented

✅ Modern React 18 + TypeScript setup
✅ Tailwind CSS with custom design system
✅ Framer Motion animations
✅ Dark/light theme toggle
✅ Fully responsive design
✅ SEO optimized (meta tags, alt text)
✅ Glassmorphism UI effects
✅ Smooth scrolling navigation
✅ Student testimonials carousel
✅ Pricing comparison table
✅ FAQ section with animations
✅ Professional footer with social links
✅ Floating WhatsApp integration
✅ Scroll-to-top functionality
✅ CountdownTimer for offers
✅ Course highlights section
✅ Feature badges with statistics

## Next Steps for Development

1. **Student Panel**: Dashboard, course access, certificates
2. **Admin Panel**: User management, course uploads
3. **Payment Integration**: Cashfree payment gateway
4. **Affiliate System**: Referral tracking, commission system
5. **AI Integration**: GrowBot assistant
6. **CareSense**: Mental wellness features
7. **Mobile App**: React Native version

## Support

For questions or support, contact: support@growsence.com
WhatsApp: +91 9876543210