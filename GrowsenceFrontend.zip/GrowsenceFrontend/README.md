# Growsence - Education & Earning Platform

A modern, production-ready frontend for Growsence education platform focused on personal growth, mental well-being, and immersive learning with affiliate earning opportunities.

## 🚀 Features

- 🎓 **Educational Courses**: Personal development, mental wellness, and income generation
- 💰 **Affiliate Marketing**: Proven strategies for passive income
- 🧠 **Mental Well-being**: Comprehensive mindfulness and emotional intelligence programs
- 🚀 **Modern UI/UX**: Glassmorphism, smooth animations, and responsive design
- 🌓 **Dark/Light Theme**: Seamless theme switching with persistence
- 📱 **Mobile-First**: Fully responsive design for all devices

## 🛠️ Tech Stack

- **Frontend**: React 18 + TypeScript
- **Styling**: Tailwind CSS + shadcn/ui
- **Animations**: Framer Motion
- **Routing**: Wouter
- **State Management**: React Query
- **Build Tool**: Vite
- **Backend**: Express.js + TypeScript
- **Database**: PostgreSQL with Drizzle ORM

## 🏁 Quick Start

1. Install dependencies:
```bash
npm install
```

2. Start development server:
```bash
npm run dev
```

3. Open http://localhost:5000 in your browser

## 📁 Project Structure

```
growsence/
├── client/          # React frontend
│   ├── src/
│   │   ├── components/  # UI components
│   │   ├── pages/       # Page components
│   │   ├── hooks/       # Custom hooks
│   │   └── lib/         # Utilities
├── server/          # Express backend
├── shared/          # Shared types
└── ...config files
```

## 📜 Available Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run preview` - Preview production build

## 🎯 Homepage Features

### Main Sections
- Hero section with typing animation
- About Growsence
- Course highlights
- Feature badges (12+ courses, 750+ students, ₹15L+ earnings)
- Student testimonials carousel
- Pricing table (Basic ₹1,499 vs Pro ₹2,999)
- How it works (Learn → Earn → Grow)
- Countdown timer for offers
- FAQ section
- Professional footer

### UI/UX Features
- Glassmorphism effects
- Smooth scroll animations
- Hover effects and transitions
- Floating WhatsApp button
- Scroll-to-top functionality
- Dark/light theme toggle
- Mobile-responsive design

## 🚀 Deployment

### Vercel (Recommended)
1. Push to GitHub
2. Connect repository to Vercel
3. Deploy automatically

### Manual Deployment
1. Build the project: `npm run build`
2. Deploy the `dist/` folder to your hosting service

## 🔧 Environment Variables

Create a `.env` file:
```
DATABASE_URL=your_database_url
NODE_ENV=production
PORT=5000
```

## ✅ Current Implementation Status

✅ Modern React 18 + TypeScript setup
✅ Tailwind CSS with custom design system
✅ Framer Motion animations
✅ Dark/light theme toggle
✅ Fully responsive design
✅ SEO optimized (meta tags, alt text)
✅ Glassmorphism UI effects
✅ Smooth scrolling navigation
✅ Student testimonials carousel
✅ Pricing comparison table
✅ FAQ section with animations
✅ Professional footer with social links
✅ Floating WhatsApp integration
✅ Scroll-to-top functionality
✅ Countdown timer for offers
✅ Course highlights section
✅ Feature badges with statistics

## 🔄 Next Development Phase

1. **Student Panel**: Dashboard, course access, certificates
2. **Admin Panel**: User management, course uploads
3. **Payment Integration**: Cashfree payment gateway
4. **Affiliate System**: Referral tracking, commission system
5. **AI Integration**: GrowBot assistant
6. **CareSense**: Mental wellness features
7. **Mobile App**: React Native version

## 💬 Support

For questions or support:
- Email: support@growsence.com
- WhatsApp: +91 9876543210
- Instagram: @growsenceindia

## 📄 License

MIT License - see LICENSE file for details