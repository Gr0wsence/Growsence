# Growsence - Educational Platform

## Overview

Growsence is a modern educational platform focused on personal development, mental well-being, and income generation strategies. The application combines learning with earning opportunities through affiliate marketing and digital products. It features a comprehensive course system, user testimonials, pricing tiers, and community features.

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Changes

- **January 9, 2025**: Created complete frontend for Growsence education platform
- **Project Status**: Production-ready homepage with all required sections implemented
- **Next Phase**: Ready for GitHub deployment and backend integration

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **UI Library**: Radix UI with shadcn/ui components
- **Styling**: Tailwind CSS with CSS variables for theming
- **Routing**: Wouter for client-side navigation
- **State Management**: React Query (@tanstack/react-query) for server state
- **Animations**: Framer Motion for smooth animations and transitions
- **Build Tool**: Vite for development and production builds

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript with ES modules
- **Database**: PostgreSQL with Neon serverless database
- **ORM**: Drizzle ORM for database operations and migrations
- **Session Management**: Connect-pg-simple for PostgreSQL session storage
- **API Structure**: RESTful API design with /api prefix

### Key Components

1. **Landing Page System**
   - Hero section with typing animation
   - About section with feature highlights
   - Course showcase with pricing
   - Feature badges displaying metrics
   - Testimonials carousel
   - Pricing comparison table
   - FAQ section with collapsible items
   - Footer with social links

2. **Theme System**
   - Light/dark mode toggle
   - CSS variables for consistent theming
   - Tailwind CSS integration
   - Persistent theme preference storage

3. **Component Library**
   - Comprehensive UI components from Radix UI
   - Custom styled components with shadcn/ui
   - Responsive design patterns
   - Accessible interactive elements

4. **User Management**
   - Basic user schema with username/password
   - Memory storage implementation (development)
   - Prepared for database migration

## Data Flow

1. **Client-Side Rendering**
   - React components fetch data using React Query
   - Smooth page transitions with Wouter routing
   - Theme persistence through localStorage

2. **Server Communication**
   - API requests through custom fetch wrapper
   - Error handling with toast notifications
   - Credential-based authentication ready

3. **Database Operations**
   - Drizzle ORM for type-safe database queries
   - Migration system for schema changes
   - PostgreSQL with connection pooling

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: Serverless PostgreSQL driver
- **drizzle-orm**: Type-safe ORM for database operations
- **@tanstack/react-query**: Server state management
- **wouter**: Lightweight React router
- **framer-motion**: Animation library

### UI Dependencies
- **@radix-ui**: Unstyled, accessible UI primitives
- **tailwindcss**: Utility-first CSS framework
- **lucide-react**: Icon library
- **class-variance-authority**: Utility for styling variants

### Development Dependencies
- **vite**: Build tool and development server
- **typescript**: Type checking and compilation
- **drizzle-kit**: Database migration tool

## Deployment Strategy

### Development Setup
- **Environment**: Development mode with hot reload
- **Database**: Neon serverless PostgreSQL
- **Build Process**: Vite handles client-side bundling
- **Server**: Express.js with TypeScript compilation

### Production Build
- **Client Build**: Vite builds optimized static assets
- **Server Build**: esbuild compiles TypeScript to JavaScript
- **Database**: Production PostgreSQL with migrations
- **Environment Variables**: DATABASE_URL required for database connection

### Key Features Ready for Enhancement
1. **Authentication System**: User schema and storage interface prepared
2. **Course Management**: UI components ready for course content
3. **Payment Integration**: Pricing components prepared for payment processors
4. **Community Features**: UI framework ready for user interactions
5. **Analytics**: Component structure supports metrics tracking
6. **SEO Optimization**: Meta tags and structured data implemented

The application follows modern React patterns with TypeScript for type safety, uses industry-standard tools for development workflow, and maintains a clean separation between frontend and backend concerns. The modular component structure allows for easy feature additions and customization.