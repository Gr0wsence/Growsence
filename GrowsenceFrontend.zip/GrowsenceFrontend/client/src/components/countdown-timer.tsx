import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Clock } from "lucide-react";

export function CountdownTimer() {
  const [timeLeft, setTimeLeft] = useState({
    days: 5,
    hours: 14,
    minutes: 32,
    seconds: 18
  });

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        let { days, hours, minutes, seconds } = prev;
        
        if (seconds > 0) {
          seconds--;
        } else if (minutes > 0) {
          minutes--;
          seconds = 59;
        } else if (hours > 0) {
          hours--;
          minutes = 59;
          seconds = 59;
        } else if (days > 0) {
          days--;
          hours = 23;
          minutes = 59;
          seconds = 59;
        }
        
        return { days, hours, minutes, seconds };
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const scrollToSection = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  return (
    <section className="py-20 bg-gradient-to-r from-primary to-secondary text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Limited Time Offer</h2>
          <p className="text-lg text-blue-100 mb-8 max-w-2xl mx-auto">
            Get 40% off on all courses and unlock your potential today. This special discount expires soon!
          </p>
          
          {/* Countdown Timer */}
          <div className="flex justify-center space-x-4 md:space-x-8 mb-8">
            {Object.entries(timeLeft).map(([unit, value]) => (
              <motion.div
                key={unit}
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.6, delay: Object.keys(timeLeft).indexOf(unit) * 0.1 }}
                viewport={{ once: true }}
                className="text-center"
              >
                <div className="bg-white/20 backdrop-blur-md rounded-lg p-4 min-w-[80px]">
                  <div className="text-2xl md:text-3xl font-bold">
                    {value.toString().padStart(2, '0')}
                  </div>
                  <div className="text-sm text-blue-100 capitalize">
                    {unit}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
          
          <div className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-6">
            <Button
              onClick={() => scrollToSection("#pricing")}
              className="bg-white text-primary hover:bg-gray-100 px-8 py-4 text-lg font-semibold hover-lift"
            >
              Claim Your Discount
            </Button>
            <div className="text-sm text-blue-100 flex items-center">
              <Clock className="h-4 w-4 mr-2" />
              Offer valid until supplies last
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
