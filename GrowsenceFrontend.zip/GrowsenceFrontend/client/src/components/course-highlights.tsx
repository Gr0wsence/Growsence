import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Star } from "lucide-react";

export function CourseHighlights() {
  const courses = [
    {
      title: "Mindful Living Mastery",
      description: "Learn evidence-based mindfulness techniques to reduce stress, improve focus, and enhance your overall well-being.",
      price: "₹999",
      rating: 4.9,
      reviews: 234,
      category: "Mindfulness",
      image: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&h=300",
      categoryColor: "bg-primary/10 text-primary"
    },
    {
      title: "Affiliate Marketing Blueprint",
      description: "Master the art of affiliate marketing with proven strategies that generate consistent passive income.",
      price: "₹1,499",
      rating: 4.8,
      reviews: 189,
      category: "Marketing",
      image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&h=300",
      categoryColor: "bg-secondary/10 text-secondary"
    },
    {
      title: "Emotional Intelligence Pro",
      description: "Develop superior emotional intelligence skills to enhance your relationships and career success.",
      price: "₹1,299",
      rating: 4.9,
      reviews: 312,
      category: "Leadership",
      image: "https://images.unsplash.com/photo-1559136555-9303baea8ebd?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&h=300",
      categoryColor: "bg-accent/10 text-accent"
    }
  ];

  const scrollToSection = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  return (
    <section id="courses" className="py-20 bg-muted/50 dark:bg-muted/10 transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Featured Courses</h2>
          <p className="text-lg text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            Discover our most popular courses designed to accelerate your personal growth and earning potential.
          </p>
        </motion.div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {courses.map((course, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.2 }}
              viewport={{ once: true }}
              className="bg-card dark:bg-card rounded-xl shadow-lg hover-lift transition-all duration-300 overflow-hidden"
            >
              <img 
                src={course.image}
                alt={course.title}
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <span className={`px-3 py-1 rounded-full text-sm font-medium ${course.categoryColor}`}>
                    {course.category}
                  </span>
                  <span className="text-accent font-semibold">{course.price}</span>
                </div>
                <h3 className="text-xl font-bold mb-3">{course.title}</h3>
                <p className="text-gray-600 dark:text-gray-300 mb-4">
                  {course.description}
                </p>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Star className="h-4 w-4 text-yellow-400 fill-current" />
                    <span className="text-sm text-gray-600 dark:text-gray-400">
                      {course.rating} ({course.reviews} reviews)
                    </span>
                  </div>
                  <Button className="bg-primary hover:bg-primary/90 text-white">
                    Enroll Now
                  </Button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
        
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          viewport={{ once: true }}
          className="text-center mt-12"
        >
          <Button
            onClick={() => scrollToSection("#pricing")}
            className="bg-secondary hover:bg-secondary/90 text-white px-8 py-4 text-lg font-semibold hover-lift"
          >
            View All Courses
          </Button>
        </motion.div>
      </div>
    </section>
  );
}
