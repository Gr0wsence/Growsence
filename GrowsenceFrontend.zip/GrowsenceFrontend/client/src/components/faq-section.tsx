import { useState } from "react";
import { motion } from "framer-motion";
import { ChevronDown } from "lucide-react";

export function FAQSection() {
  const [openFAQ, setOpenFAQ] = useState<number | null>(null);

  const faqs = [
    {
      question: "How quickly can I start earning through affiliate marketing?",
      answer: "Most students start seeing their first earnings within 30-60 days of completing our affiliate marketing course. However, success depends on your commitment, implementation of strategies, and market conditions. Our top performers have generated their first ₹10,000 within the first month."
    },
    {
      question: "What makes Growsence different from other online education platforms?",
      answer: "Growsence uniquely combines personal development with practical income generation strategies. Unlike traditional education platforms, we focus on both mental well-being and financial freedom. Our courses are designed by industry experts, include 1:1 mentoring, and provide proven affiliate marketing tools that our students use to generate real income."
    },
    {
      question: "Do I need any prior experience to join your courses?",
      answer: "No prior experience is required! Our courses are designed for beginners and advanced learners alike. We start with foundational concepts and gradually build up to advanced strategies. Our step-by-step approach ensures that anyone can succeed, regardless of their starting point."
    },
    {
      question: "What kind of support do you provide to students?",
      answer: "We provide comprehensive support including email assistance, community forums, weekly live Q&A sessions, and for Pro members, monthly 1:1 mentoring calls. Our dedicated support team is available to help you succeed at every step of your journey."
    },
    {
      question: "Is there a money-back guarantee?",
      answer: "Yes! We offer a 30-day money-back guarantee. If you're not completely satisfied with your learning experience within the first 30 days, we'll refund your investment, no questions asked. We're confident in the value we provide and stand behind our courses."
    },
    {
      question: "Can I upgrade or downgrade my plan anytime?",
      answer: "Absolutely! You can upgrade or downgrade your plan at any time. When you upgrade, you'll get immediate access to additional features. If you downgrade, the changes will take effect at your next billing cycle. There are no long-term contracts or hidden fees."
    }
  ];

  const toggleFAQ = (index: number) => {
    setOpenFAQ(openFAQ === index ? null : index);
  };

  return (
    <section id="faq" className="py-20 bg-muted/50 dark:bg-muted/10 transition-colors duration-300">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Frequently Asked Questions</h2>
          <p className="text-lg text-gray-600 dark:text-gray-300">
            Got questions? We've got answers. Find everything you need to know about our platform.
          </p>
        </motion.div>
        
        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
              className="bg-card dark:bg-card rounded-xl shadow-lg"
            >
              <button
                onClick={() => toggleFAQ(index)}
                className="w-full text-left p-6 focus:outline-none"
              >
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-semibold pr-4">{faq.question}</h3>
                  <ChevronDown 
                    className={`h-5 w-5 text-gray-400 transition-transform duration-300 ${
                      openFAQ === index ? 'rotate-180' : ''
                    }`}
                  />
                </div>
              </button>
              {openFAQ === index && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  transition={{ duration: 0.3 }}
                  className="px-6 pb-6"
                >
                  <p className="text-gray-600 dark:text-gray-300">
                    {faq.answer}
                  </p>
                </motion.div>
              )}
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
