import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Check } from "lucide-react";

export function PricingTable() {
  const plans = [
    {
      name: "Basic Plan",
      price: "₹1,499",
      period: "/month",
      description: "Perfect for beginners starting their growth journey",
      features: [
        "Access to 5 core courses",
        "Basic community access",
        "Email support",
        "Monthly group webinars",
        "Basic affiliate tools"
      ],
      popular: false,
      buttonText: "Get Started",
      buttonVariant: "outline" as const
    },
    {
      name: "Pro Plan",
      price: "₹2,999",
      period: "/month",
      description: "Complete access with premium features and support",
      features: [
        "Access to all 12+ courses",
        "Premium community access",
        "Priority 1:1 support",
        "Weekly live coaching sessions",
        "Advanced affiliate tools & analytics",
        "Monthly one-on-one mentoring",
        "Certificate of completion"
      ],
      popular: true,
      buttonText: "Start Pro Plan",
      buttonVariant: "default" as const
    }
  ];

  const scrollToSection = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  return (
    <section id="pricing" className="py-20 bg-muted/50 dark:bg-muted/10 transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Choose Your Growth Plan</h2>
          <p className="text-lg text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            Select the perfect plan to accelerate your personal development journey and earning potential.
          </p>
        </motion.div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
          {plans.map((plan, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.2 }}
              viewport={{ once: true }}
              className={`bg-card dark:bg-card rounded-xl shadow-lg hover-lift transition-all duration-300 overflow-hidden relative ${
                plan.popular ? 'ring-2 ring-primary' : ''
              }`}
            >
              {plan.popular && (
                <div className="absolute top-0 right-0 bg-primary text-white px-4 py-2 rounded-bl-xl font-semibold">
                  Most Popular
                </div>
              )}
              
              <div className="p-8">
                <div className="text-center mb-8">
                  <h3 className="text-2xl font-bold mb-2">{plan.name}</h3>
                  <p className="text-gray-600 dark:text-gray-300 mb-6">{plan.description}</p>
                  <div className="flex items-center justify-center">
                    <span className={`text-4xl font-bold ${plan.popular ? 'text-primary' : 'text-foreground'}`}>
                      {plan.price}
                    </span>
                    <span className="text-gray-600 dark:text-gray-300 ml-2">{plan.period}</span>
                  </div>
                </div>
                
                <ul className="space-y-4 mb-8">
                  {plan.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center">
                      <Check className="h-5 w-5 text-secondary mr-3" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
                
                <Button
                  variant={plan.buttonVariant}
                  className={`w-full py-4 font-semibold ${
                    plan.popular ? 'bg-primary hover:bg-primary/90 text-white' : ''
                  }`}
                >
                  {plan.buttonText}
                </Button>
              </div>
            </motion.div>
          ))}
        </div>
        
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          viewport={{ once: true }}
          className="text-center mt-12"
        >
          <p className="text-gray-600 dark:text-gray-300 mb-4">
            30-day money-back guarantee • No long-term contracts • Cancel anytime
          </p>
          <button
            onClick={() => scrollToSection("#faq")}
            className="text-primary hover:text-primary/80 font-medium"
          >
            Have questions? Check our FAQ section
          </button>
        </motion.div>
      </div>
    </section>
  );
}
