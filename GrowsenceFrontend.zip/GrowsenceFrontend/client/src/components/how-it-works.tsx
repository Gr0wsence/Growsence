import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { BookOpen, Coins, TrendingUp, Check } from "lucide-react";

export function HowItWorks() {
  const steps = [
    {
      number: 1,
      title: "Learn",
      icon: BookOpen,
      description: "Access expertly crafted courses on personal development, mental well-being, and proven income strategies. Learn at your own pace with interactive content.",
      color: "bg-primary/10 text-primary",
      features: [
        "Video lessons & resources",
        "Interactive exercises",
        "Community discussions"
      ]
    },
    {
      number: 2,
      title: "Earn",
      icon: Coins,
      description: "Apply your knowledge to generate income through affiliate marketing, digital products, and our proven earning strategies. Start monetizing your growth.",
      color: "bg-secondary/10 text-secondary",
      features: [
        "Affiliate marketing tools",
        "Passive income strategies",
        "Performance analytics"
      ]
    },
    {
      number: 3,
      title: "Grow",
      icon: TrendingUp,
      description: "Scale your success with advanced strategies, mentorship, and community support. Transform your life and help others do the same.",
      color: "bg-accent/10 text-accent",
      features: [
        "Advanced courses & tools",
        "1:1 mentoring sessions",
        "Leadership opportunities"
      ]
    }
  ];

  const scrollToSection = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  return (
    <section className="py-20 bg-background dark:bg-background transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-6">How It Works</h2>
          <p className="text-lg text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            Your journey to personal growth and financial freedom in three simple steps.
          </p>
        </motion.div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {steps.map((step, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.2 }}
              viewport={{ once: true }}
              className="text-center group"
            >
              <div className="relative mb-8">
                <div className={`w-24 h-24 ${step.color.replace('text-', 'group-hover:bg-').replace('/10', '/20')} rounded-full flex items-center justify-center mx-auto transition-colors duration-300`}>
                  <step.icon className={`${step.color.split(' ')[1]} h-12 w-12`} />
                </div>
                <div className={`absolute -top-2 -right-2 w-8 h-8 ${step.color.split(' ')[1].replace('text-', 'bg-')} text-white rounded-full flex items-center justify-center font-bold`}>
                  {step.number}
                </div>
              </div>
              <h3 className="text-2xl font-bold mb-4 gradient-text">{step.title}</h3>
              <p className="text-gray-600 dark:text-gray-300 mb-6">
                {step.description}
              </p>
              <ul className="text-left space-y-2">
                {step.features.map((feature, featureIndex) => (
                  <li key={featureIndex} className="flex items-center">
                    <Check className="h-4 w-4 text-secondary mr-2" />
                    <span className="text-sm">{feature}</span>
                  </li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>
        
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          viewport={{ once: true }}
          className="text-center mt-16"
        >
          <Button
            onClick={() => scrollToSection("#pricing")}
            className="bg-primary hover:bg-primary/90 text-white px-8 py-4 text-lg font-semibold hover-lift"
          >
            Start Your Journey Today
          </Button>
        </motion.div>
      </div>
    </section>
  );
}
