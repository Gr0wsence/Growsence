import { motion } from "framer-motion";
import { Brain, TrendingUp, Users } from "lucide-react";

export function AboutSection() {
  const features = [
    {
      icon: Brain,
      title: "Mental Well-being Focus",
      description: "Comprehensive programs designed to enhance your mental health, emotional intelligence, and overall well-being.",
      color: "text-primary"
    },
    {
      icon: TrendingUp,
      title: "Proven Earning Strategies",
      description: "Learn affiliate marketing, digital product creation, and passive income generation from industry experts.",
      color: "text-secondary"
    },
    {
      icon: Users,
      title: "Community Support",
      description: "Join a thriving community of like-minded individuals committed to growth and success.",
      color: "text-accent"
    }
  ];

  return (
    <section id="about" className="py-20 bg-background dark:bg-background transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-6">About Growsence</h2>
          <p className="text-lg text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            We believe that personal growth and financial freedom go hand in hand. Our platform combines cutting-edge education with proven earning strategies to help you transform your life.
          </p>
        </motion.div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Left content */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h3 className="text-2xl md:text-3xl font-bold mb-6">
              Empowering Your Journey to 
              <span className="gradient-text"> Personal Excellence</span>
            </h3>
            
            <div className="space-y-6">
              {features.map((feature, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.2 }}
                  viewport={{ once: true }}
                  className="flex items-start space-x-4"
                >
                  <div className={`flex-shrink-0 w-12 h-12 bg-${feature.color.split('-')[1]}/10 rounded-lg flex items-center justify-center`}>
                    <feature.icon className={`${feature.color} h-6 w-6`} />
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold mb-2">{feature.title}</h4>
                    <p className="text-gray-600 dark:text-gray-300">
                      {feature.description}
                    </p>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
          
          {/* Right image */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="relative"
          >
            <img 
              src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&h=600" 
              alt="Students collaborating in modern learning environment" 
              className="rounded-2xl shadow-2xl hover-scale transition-transform duration-300"
            />
            
            {/* Floating stats card */}
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              viewport={{ once: true }}
              className="absolute -bottom-6 -left-6 bg-white dark:bg-gray-800 p-6 rounded-xl shadow-lg animate-float"
            >
              <div className="text-2xl font-bold text-primary mb-1">95%</div>
              <div className="text-sm text-gray-600 dark:text-gray-400">Success Rate</div>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
