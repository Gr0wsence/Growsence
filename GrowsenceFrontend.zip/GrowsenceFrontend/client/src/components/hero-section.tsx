import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { ChevronDown, Rocket, Play } from "lucide-react";

export function HeroSection() {
  const [typingText, setTypingText] = useState("");
  const fullText = "Earning Potential";

  useEffect(() => {
    let index = 0;
    const typingInterval = setInterval(() => {
      if (index < fullText.length) {
        setTypingText(fullText.substring(0, index + 1));
        index++;
      } else {
        clearInterval(typingInterval);
      }
    }, 100);

    return () => clearInterval(typingInterval);
  }, []);

  const scrollToSection = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center bg-gradient-to-br from-primary/10 to-secondary/10 dark:from-primary/20 dark:to-secondary/20">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-30">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-secondary/5"></div>
      </div>
      
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          {/* Floating elements */}
          <div className="absolute top-20 left-10 w-20 h-20 bg-primary/20 rounded-full blur-xl animate-pulse-slow"></div>
          <div className="absolute bottom-20 right-10 w-32 h-32 bg-secondary/20 rounded-full blur-xl animate-pulse-slow"></div>
          
          {/* Main heading */}
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold leading-tight mb-6">
            Transform Your Learning Journey into
            <span className="block gradient-text">
              {typingText}
              <span className="animate-pulse">|</span>
            </span>
          </h1>
          
          {/* Subheading */}
          <p className="text-lg md:text-xl text-gray-600 dark:text-gray-300 mb-8 max-w-3xl mx-auto">
            Join thousands of learners who are mastering personal growth, mental well-being, and building sustainable income through our immersive education platform.
          </p>
          
          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-6 mb-12">
            <Button
              onClick={() => scrollToSection("#courses")}
              className="bg-primary hover:bg-primary/90 text-white px-8 py-4 text-lg font-semibold hover-lift shadow-lg"
            >
              <Rocket className="mr-2 h-5 w-5" />
              Start Learning Today
            </Button>
            <Button
              variant="outline"
              onClick={() => scrollToSection("#about")}
              className="glass dark:glass-dark text-gray-700 dark:text-gray-300 hover:text-primary px-8 py-4 text-lg font-semibold hover-lift"
            >
              <Play className="mr-2 h-5 w-5" />
              Watch Demo
            </Button>
          </div>
          
          {/* Hero Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="glass dark:glass-dark p-6 rounded-xl hover-lift"
            >
              <div className="text-3xl font-bold text-primary mb-2">12+</div>
              <div className="text-sm text-gray-600 dark:text-gray-400">Expert Courses</div>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              className="glass dark:glass-dark p-6 rounded-xl hover-lift"
            >
              <div className="text-3xl font-bold text-secondary mb-2">750+</div>
              <div className="text-sm text-gray-600 dark:text-gray-400">Happy Students</div>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.6 }}
              className="glass dark:glass-dark p-6 rounded-xl hover-lift"
            >
              <div className="text-3xl font-bold text-accent mb-2">₹15L+</div>
              <div className="text-sm text-gray-600 dark:text-gray-400">Total Earnings</div>
            </motion.div>
          </div>
        </motion.div>
      </div>
      
      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce-gentle">
        <button
          onClick={() => scrollToSection("#about")}
          className="text-gray-400 hover:text-primary transition-colors"
        >
          <ChevronDown className="h-8 w-8" />
        </button>
      </div>
    </section>
  );
}
