import { Navigation } from "@/components/navigation";
import { HeroSection } from "@/components/hero-section";
import { AboutSection } from "@/components/about-section";
import { CourseHighlights } from "@/components/course-highlights";
import { FeatureBadges } from "@/components/feature-badges";
import { TestimonialsCarousel } from "@/components/testimonials-carousel";
import { PricingTable } from "@/components/pricing-table";
import { HowItWorks } from "@/components/how-it-works";
import { CountdownTimer } from "@/components/countdown-timer";
import { FAQSection } from "@/components/faq-section";
import { Footer } from "@/components/footer";
import { ScrollToTop } from "@/components/scroll-to-top";
import { FloatingWhatsApp } from "@/components/floating-whatsapp";

export default function Home() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <Navigation />
      <HeroSection />
      <AboutSection />
      <CourseHighlights />
      <FeatureBadges />
      <TestimonialsCarousel />
      <PricingTable />
      <HowItWorks />
      <CountdownTimer />
      <FAQSection />
      <Footer />
      <ScrollToTop />
      <FloatingWhatsApp />
    </div>
  );
}
